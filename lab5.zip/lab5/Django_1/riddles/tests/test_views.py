import json

from django.test import TestCase, Client
from django.urls import reverse
from riddles.models import Riddle, Option
import datetime

# класс - набор тестов
class TestViews(TestCase):
    # настройка, выполняемая перед запуском тестов:
    # подготовка эмулятора браузера (Client) и url-ов,
    def setUp(self):
        self.client = Client()
        self.index_url = reverse('riddles:index')
        # будем искать загадку с riddle_id = 1
        self.detail_url = reverse('riddles:detail', args=['1'])
        self.answer_url = reverse('riddles:answer', args=['1'])
        self.riddle1 = Riddle.objects.create(
            riddle_text = 'Зимой и летом одним цветом.',
            pub_date = datetime.datetime.today()
        )
        self.option1 = Option.objects.create(
            riddle=self.riddle1,
            text='Дуб',
            correct=False
        )
        self.option2 = Option.objects.create(
            riddle=self.riddle1,
            text='Елка',
            correct=True
        )

    # тест 1:
    # главная страница со списком загадок генерируется успешно (код 200) и на основе шаблона index.html?
    def test_riddles_list_GET(self):
        # обращение эмулятора браузера к странице со списком загадок
        response = self.client.get(self.index_url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'index.html')

    # тест 2:
    # страница с ответами для выбранной загадки генерируется успешно (код 200)
    # и на основе шаблона answer.html
    # а также генерируется новый url, содержащий id искомой загадки
    def test_riddle_detail_GET(self):
        response = self.client.get(self.detail_url, riddle_id=1)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'answer.html')
        self.assertEquals(response.request['PATH_INFO'], '/riddles/1/')

    # тест 3:
    # выбор неправильного ответа на загадку заканчивается переадресацией (код 302) на ту же страницу
    # и сообщение об ошибке содержит "Wrong Answer!"
    def test_riddle_detail_POST_wrong_option(self):
        #response = None
        try:
            response = self.client.post(self.answer_url, {
                'option': self.option1.id
            })
        except:
            print('exception\n')
        print('---===', response, "===---")
        self.assertEquals(response.status_code, 302)
        self.assertEquals(response.url, '/riddles/1?error_message=Wrong%20Answer!')


