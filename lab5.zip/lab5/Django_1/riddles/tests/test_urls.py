from django.test import SimpleTestCase
from django.urls import reverse, resolve
from riddles.views import index, detail, answer

# класс - набор тестов для проверки работы url
class TestUrls(SimpleTestCase):
    # тест 1:
    # главная страница генерируется функцией index?
    def test_index_url_resolves(self):
        url = reverse('riddles:index')
        # сравнение функции, используемой для обработки полученного url, c функцией index
        self.assertEquals(resolve(url).func, index)

    # тест 2:
    # страница загадки со списком ответов генерируется функцией detail?
    def test_detail_url_resolves(self):
        # для примера в качестве аргумента берем первый элемент из таблицы (riddle_id = 1)
        url = reverse('riddles:detail', args=['1'])
        # сравнение функции, используемой для обработки полученного url, c функцией detail
        self.assertEquals(resolve(url).func, detail)

    # тест 3:
    # страница проверки ответа на выбранную загадку (redirect на саму себя или на index) генерируется функцией detail?
    def test_answer_url_resolves(self):
        # для примера в качестве аргумента берем первый элемент из таблицы загадок (riddle_id = 1)
        url = reverse('riddles:answer', args=['1'])
        # сравнение функции, используемой для обработки полученного url, c функцией answer
        self.assertEquals(resolve(url).func, answer)